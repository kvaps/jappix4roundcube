﻿<?php

// If fou want to use an extenal jappix, please provide jappix url
$rcmail_config['jappix_embedded'] = false;
$rcmail_config['jappix_url'] = 'https://jappix.com';

// Enables full jappix mode
$rcmail_config['jappix_task'] = true;

?>
