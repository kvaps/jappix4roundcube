Jappix Thanks
=============

We would like to thanks the authors of these tools, coming from other projects:


Projects
--------

* Base64            https://github.com/dankogai/js-base64
* DrawSVGChart      http://codingteam.net/project/codingteam
* idzXHR            http://www.iadvize.com/plugin_strophe_xmpp.html
* JSJaC             http://blog.jwchat.org/jsjac/
* JSMin             http://github.com/rgrove/jsmin-php/
* jQuery            http://jquery.com/
* jQuery Form       http://jquery.malsup.com/form/
* jQuery Timers     http://plugins.jquery.com/project/timers
* jXHR              http://mulletxhr.com/
* Mobile Detect     https://github.com/serbanghita/Mobile-Detect
* ParaType          http://paratype.ru/
* PHP-gettext       https://launchpad.net/php-gettext   
* Silk icons        http://www.famfamfam.com/lab/icons/silk/
* Smileys           http://www.gajim.org/
