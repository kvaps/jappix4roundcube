Jappix Installation
===================

It's very simple to install Jappix on your webserver, you just have to follow these things:


Installation
------------

* The HTTP server: https://github.com/jappix/jappix/wiki/HttpServer
* The XMPP server: https://github.com/jappix/jappix/wiki/XmppServer
* The BOSH server: https://github.com/jappix/jappix/wiki/BoshServer
* The Jappix app : https://github.com/jappix/jappix/wiki/JappixApp

More
----

* The whole documentation is available at: https://github.com/jappix/jappix/wiki


Now, you can use Jappix. Happy socializing!
